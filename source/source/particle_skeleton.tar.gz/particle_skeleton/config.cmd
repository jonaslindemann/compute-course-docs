@echo off

rem --- Configuration variables (call from the other scripts after setlocal)

set BUILD_TYPE=Release
set "BUILD_DIR=%~dp0build"
set "BIN_DIR=%~dp0bin"

rem --- Check tools

where gfortran >nul 2>&1 || (
    echo ERROR: gfortran not found in PATH.
    exit /b 1
)

if not defined CONDA_PREFIX (
    echo WARNING: No conda environment is active. Activate the project environment first.
)

rem --- Python finds the extension module in bin

set "PYTHONPATH=%BIN_DIR%;%PYTHONPATH%"

exit /b 0
