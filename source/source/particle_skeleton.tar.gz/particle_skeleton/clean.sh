#!/bin/bash

source "$(dirname "$0")/config_env.sh"

echo "Cleaning project..."

rm -rf "$BUILD_DIR" "$BIN_DIR" "$SCRIPT_DIR/lib" "$SCRIPT_DIR/particle.state"
