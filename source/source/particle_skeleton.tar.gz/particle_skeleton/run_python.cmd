@echo off
setlocal

call "%~dp0config.cmd" || exit /b 1

rem --- Run a Python script with the extension module available
rem --- Usage: run_python.cmd [script.py], default is particles.py

set SCRIPT=%1
if "%SCRIPT%"=="" set SCRIPT=particles.py

python "%~dp0%SCRIPT%"
