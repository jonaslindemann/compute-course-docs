@echo off
setlocal

call "%~dp0config.cmd" || exit /b 1

rem --- Configure a new build directory

if exist "%BUILD_DIR%" (
    echo Removing build directory...
    rmdir /Q /S "%BUILD_DIR%"
)

cmake -S "%~dp0." -B "%BUILD_DIR%" -G Ninja -DCMAKE_BUILD_TYPE=%BUILD_TYPE% -DCMAKE_Fortran_COMPILER=gfortran || exit /b 1

rem --- Build Fortran program, library and Python extension module

cmake --build "%BUILD_DIR%" || exit /b 1
