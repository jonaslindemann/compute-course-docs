#!/bin/bash

set -e

source "$(dirname "$0")/config_env.sh"

# --- Configure first if there is no build directory

if [ ! -d "$BUILD_DIR" ]; then
    exec "$SCRIPT_DIR/configure_build.sh"
fi

cmake --build "$BUILD_DIR"
