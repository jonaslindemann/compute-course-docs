@echo off
setlocal

call "%~dp0config.cmd" || exit /b 1

rem --- Run the Fortran program, writes particle.state

"%BIN_DIR%\particles.exe"
