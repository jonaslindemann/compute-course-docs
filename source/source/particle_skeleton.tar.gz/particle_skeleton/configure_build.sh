#!/bin/bash

set -e

source "$(dirname "$0")/config_env.sh"

# --- Configure a new build directory

rm -rf "$BUILD_DIR"

cmake -S "$SCRIPT_DIR" -B "$BUILD_DIR" -G Ninja -DCMAKE_BUILD_TYPE=$BUILD_TYPE -DCMAKE_Fortran_COMPILER=gfortran

# --- Build Fortran program, library and Python extension module

cmake --build "$BUILD_DIR"
