#!/usr/bin/env python
"""
Task 3: Interactive particle simulator. A Qt user interface for the
simulation parameters with an embedded PyVista 3D view.
"""

import sys

import numpy as np
import pyvista as pv
from pyvistaqt import QtInteractor
from PySide6 import QtCore, QtWidgets

from particle import particle_driver


class ParticleSimulation:
    """Python interface to the Fortran particle simulation."""

    def __init__(self):
        self.initialised = False
        self.positions = None
        self.sizes = None
        self.step_count = 0

    def init(self, n_particles, r_min, r_max, v_min, v_max):
        """Initialise a new particle system. Any previous system is replaced."""

        # TODO: Create Fortran ordered arrays for self.positions
        # (n_particles, 3) and self.sizes (n_particles), initialise the
        # Fortran particle system and get the sizes and positions.
        # Reset self.step_count and set self.initialised.

        pass

    def step(self, n_steps=1):
        """Advance the simulation n_steps time steps and update positions."""

        # TODO: Run n_steps simulation steps (collisions, boundaries,
        # update), then get the new positions into self.positions and
        # update self.step_count.

        pass

    def cleanup(self):
        """Release the Fortran particle system."""

        # TODO: Release the Fortran particle system if it is initialised.

        pass


class MainWindow(QtWidgets.QMainWindow):
    """Main window with parameter controls and a 3D view."""

    def __init__(self):
        super().__init__()

        self.setWindowTitle("Particle Simulator")
        self.resize(1200, 800)

        self.simulation = ParticleSimulation()
        self.cloud = None

        self.timer = QtCore.QTimer(self)
        self.timer.setInterval(10)
        self.timer.timeout.connect(self.on_timer)

        self.create_controls()
        self.create_view()

        splitter = QtWidgets.QSplitter()
        splitter.addWidget(self.controls)
        splitter.addWidget(self.plotter.interactor)
        splitter.setStretchFactor(1, 1)
        self.setCentralWidget(splitter)

        self.on_initialise()

    def create_controls(self):
        """Create input fields and buttons for the simulation parameters."""

        self.n_particles_spin = QtWidgets.QSpinBox()
        self.n_particles_spin.setRange(2, 10000)
        self.n_particles_spin.setValue(1000)

        self.r_min_spin = self.create_double_spin(0.001, 0.1, 0.001, 3, 0.015)
        self.r_max_spin = self.create_double_spin(0.001, 0.1, 0.001, 3, 0.045)
        self.v_min_spin = self.create_double_spin(0.0001, 0.05, 0.0005, 4, 0.001)
        self.v_max_spin = self.create_double_spin(0.0001, 0.05, 0.0005, 4, 0.009)

        self.steps_per_frame_spin = QtWidgets.QSpinBox()
        self.steps_per_frame_spin.setRange(1, 50)
        self.steps_per_frame_spin.setValue(1)

        form = QtWidgets.QFormLayout()
        form.addRow("Number of particles", self.n_particles_spin)
        form.addRow("Min radius", self.r_min_spin)
        form.addRow("Max radius", self.r_max_spin)
        form.addRow("Min speed", self.v_min_spin)
        form.addRow("Max speed", self.v_max_spin)
        form.addRow("Steps per frame", self.steps_per_frame_spin)

        self.init_button = QtWidgets.QPushButton("Initialise")
        self.init_button.clicked.connect(self.on_initialise)

        self.run_button = QtWidgets.QPushButton("Start")
        self.run_button.setCheckable(True)
        self.run_button.toggled.connect(self.on_run_toggled)

        self.step_label = QtWidgets.QLabel()

        layout = QtWidgets.QVBoxLayout()
        layout.addLayout(form)
        layout.addWidget(self.init_button)
        layout.addWidget(self.run_button)
        layout.addWidget(self.step_label)
        layout.addStretch()

        self.controls = QtWidgets.QWidget()
        self.controls.setLayout(layout)

    def create_double_spin(self, min_value, max_value, step, decimals, value):
        """Create a QDoubleSpinBox with the given settings."""

        spin = QtWidgets.QDoubleSpinBox()
        spin.setDecimals(decimals)
        spin.setRange(min_value, max_value)
        spin.setSingleStep(step)
        spin.setValue(value)
        return spin

    def create_view(self):
        """Create the embedded PyVista 3D view."""

        self.plotter = QtInteractor(self)
        self.plotter.set_background((0.2, 0.2, 0.2))
        self.plotter.add_axes()

    def update_view(self, reset_camera=False):
        """Recreate the scene for a new particle system."""

        self.plotter.clear_actors()

        self.cloud = pv.PolyData(np.ascontiguousarray(self.simulation.positions))
        self.cloud["radius"] = self.simulation.sizes

        self.plotter.add_mesh(self.cloud, scalars="radius", cmap="plasma",
                              render_points_as_spheres=True, point_size=6)
        self.plotter.add_mesh(pv.Box(bounds=(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0)),
                              style="wireframe", color="white")

        if reset_camera:
            self.plotter.reset_camera()

    def update_step_label(self):
        self.step_label.setText(f"Step: {self.simulation.step_count}")

    def on_initialise(self):
        """Initialise a new particle system from the input fields."""

        # TODO: Read the parameters from the input fields (spin boxes).
        # Show a warning with QtWidgets.QMessageBox.warning() and return
        # if a minimum value is larger than the maximum value.

        # TODO: Initialise the simulation, then call update_view() and
        # update_step_label(). Reset the camera only the first time
        # (when self.cloud is None).

        pass

    def on_run_toggled(self, running):
        """Start or stop the simulation timer."""

        # TODO: Start or stop self.timer and change the button text
        # between "Start" and "Stop".

        pass

    def on_timer(self):
        """Advance the simulation and update the 3D view."""

        # TODO: Advance the simulation the number of steps given by
        # steps_per_frame_spin. Then copy the new positions to
        # self.cloud.points, render the view and update the step label.

        pass

    def closeEvent(self, event):
        self.timer.stop()
        self.simulation.cleanup()
        self.plotter.close()
        super().closeEvent(event)


if __name__ == "__main__":

    app = QtWidgets.QApplication(sys.argv)

    window = MainWindow()
    window.show()

    sys.exit(app.exec())
