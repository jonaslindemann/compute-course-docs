@echo off
setlocal

call "%~dp0config.cmd"

echo Cleaning project...

if exist "%BUILD_DIR%" rmdir /Q /S "%BUILD_DIR%"
if exist "%BIN_DIR%" rmdir /Q /S "%BIN_DIR%"
if exist "%~dp0lib" rmdir /Q /S "%~dp0lib"
if exist "%~dp0particle.state" del "%~dp0particle.state"
