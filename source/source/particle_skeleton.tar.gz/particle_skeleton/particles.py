#!/usr/bin/env python
"""
Task 2: Run the particle simulation from Python using the Fortran
extension module. Writes particle.state, which can be viewed with
particles_player.py.
"""

import numpy as np

from particle import particle_driver

n_particles = 1000
n_steps = 500

r_min, r_max = 0.015, 0.045
v_min, v_max = 0.001, 0.009

# Arrays passed to Fortran must be Fortran ordered so that f2py can
# update them in place.

positions = np.zeros((n_particles, 3), order='F')
sizes = np.zeros(n_particles, order='F')

# TODO: Initialise the particle system with particle_driver.init_system()
# and get the particle sizes into the sizes array.

# TODO: Write the particle sizes and the number of steps to the state file.

# TODO: Run the simulation for n_steps steps. In each step check
# collisions, check boundaries, update the positions and write the
# positions to the state file.

# TODO: Get the final positions and print the range of the coordinates
# to check that all particles are still inside the box.

# TODO: Release the particle system.
