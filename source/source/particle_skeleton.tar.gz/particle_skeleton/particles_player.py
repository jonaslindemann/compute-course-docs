#!/usr/bin/env python
"""
Plays back particle traces from a particle.state file written by the
Fortran program or by particles.py.

File format (one value per line unless stated otherwise):

    n_particles
    radius               (n_particles lines)
    n_steps
    n_particles          (repeated for each step)
    x y z                (n_particles lines)

Usage: python particles_player.py [particle.state]
"""

import sys

import numpy as np
import pyvista as pv


def read_state_file(filename):
    """Read a particle state file. Returns (radius, history), where
    history has the shape (n_steps, n_particles, 3)."""

    with open(filename) as f:
        lines = f.read().split()

    n_particles = int(lines[0])
    radius = np.array(lines[1:1 + n_particles], dtype=float)
    n_steps = int(lines[1 + n_particles])

    pos = 2 + n_particles
    history = []

    # Stop at the end of the file, the simulation may have been
    # interrupted before all steps were written.

    while len(history) < n_steps and pos + 1 + 3*n_particles <= len(lines):
        n = int(lines[pos])
        block = np.array(lines[pos + 1:pos + 1 + 3*n], dtype=float)
        history.append(block.reshape(n, 3))
        pos += 1 + 3*n

    return radius, np.array(history)


class ParticlePlayer:
    """Animates particle positions read from a state file."""

    def __init__(self, plotter, radius, history):
        self.plotter = plotter
        self.history = history
        self.step = 0

        self.cloud = pv.PolyData(history[0])
        self.cloud["radius"] = radius

        plotter.add_mesh(self.cloud, scalars="radius", cmap="plasma",
                         render_points_as_spheres=True, point_size=6)
        plotter.add_mesh(pv.Box(bounds=(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0)),
                         style="wireframe", color="white")

        self.text = plotter.add_text("", position="upper_left", font_size=10)

    def update(self, timer_step=0):
        """Show the next step, starts over at the end."""

        self.cloud.points = self.history[self.step]
        self.text.SetText(2, f"Step {self.step + 1} / {len(self.history)}")

        self.step = (self.step + 1) % len(self.history)


if __name__ == "__main__":

    filename = sys.argv[1] if len(sys.argv) > 1 else "particle.state"

    print(f"Reading {filename}...")
    radius, history = read_state_file(filename)
    print(f"{len(radius)} particles, {len(history)} steps")

    plotter = pv.Plotter(title="Particle Player")
    plotter.set_background((0.2, 0.2, 0.2))
    plotter.add_axes()

    player = ParticlePlayer(plotter, radius, history)

    # The interactor must be initialised before a timer can be created (required on Windows)

    plotter.iren.initialize()
    plotter.add_timer_event(max_steps=10**9, duration=20, callback=player.update)

    plotter.show()
