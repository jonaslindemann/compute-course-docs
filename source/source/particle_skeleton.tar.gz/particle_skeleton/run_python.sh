#!/bin/bash

source "$(dirname "$0")/config_env.sh"

# --- Run a Python script with the extension module available
# --- Usage: ./run_python.sh [script.py], default is particles.py

python "$SCRIPT_DIR/${1:-particles.py}"
