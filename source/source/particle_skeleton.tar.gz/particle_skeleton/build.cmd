@echo off
setlocal

call "%~dp0config.cmd" || exit /b 1

rem --- Configure first if there is no build directory

if not exist "%BUILD_DIR%" (
    call "%~dp0configure_build.cmd"
    exit /b
)

cmake --build "%BUILD_DIR%" || exit /b 1
