# Particles in a box - project skeleton

Skeleton code for the particle simulation project. The simulation is
implemented in Fortran and used both from a Fortran program and from
Python through an extension module built with f2py. See the assignment
on the course web page for the full instructions.

## Directory layout

| Path | Contents |
|------|----------|
| `src/common/mf_datatypes.f90` | Kind parameters and constants |
| `src/common/particle_data.f90` | The `particle_system` type and its methods |
| `src/common/particle_sim.f90` | Submodule with the simulation procedures |
| `src/common/particle_state.f90` | Particle system used by the Python module |
| `src/particles/main.f90` | Fortran main program |
| `src/particle-lib/particle_driver.f90` | Interface wrapped by f2py |
| `particles.py` | Python program running the simulation |
| `particles_qt.py` | Interactive simulator with a Qt user interface |
| `particles_player.py` | Plays back a `particle.state` file |

Code marked with `TODO` should be completed.

## Requirements

* A Fortran compiler, gfortran 9 or newer. On Windows use a MinGW-w64
  gfortran, for example from MSYS2, WinLibs or the MinGW toolchain
  installed with Qt. `gfortran` must be in `PATH`.
* A conda environment with Python and the packages below.

Create the environment (on Linux and macOS add `gfortran` to the list
if you do not have a Fortran compiler installed):

    conda create -n particles-project -c conda-forge python=3.12 numpy meson ninja cmake pyvista pyvistaqt pyside6
    conda activate particles-project

## Building

Activate the environment first. The build creates `bin/particles` (the
Fortran program) and the Python extension module `particle` in `bin/`.

| | Windows | Linux / macOS |
|---|---|---|
| Configure and build | `configure_build.cmd` | `./configure_build.sh` |
| Rebuild after changes | `build.cmd` | `./build.sh` |
| Remove build files | `clean.cmd` | `./clean.sh` |

## Running

Run the scripts from the project directory. They write and read
`particle.state` in the current directory.

| | Windows | Linux / macOS |
|---|---|---|
| Fortran program | `run_fortran.cmd` | `./run_fortran.sh` |
| Python program | `run_python.cmd` | `./run_python.sh` |
| Play back `particle.state` | `run_python.cmd particles_player.py` | `./run_python.sh particles_player.py` |
| Interactive simulator | `run_python.cmd particles_qt.py` | `./run_python.sh particles_qt.py` |
