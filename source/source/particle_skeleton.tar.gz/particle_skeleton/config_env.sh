# --- Configuration variables (sourced by the other scripts)

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

BUILD_TYPE=Release
BUILD_DIR="$SCRIPT_DIR/build"
BIN_DIR="$SCRIPT_DIR/bin"

# --- Check tools

if ! command -v gfortran > /dev/null; then
    echo "ERROR: gfortran not found in PATH."
    exit 1
fi

if [ -z "$CONDA_PREFIX" ]; then
    echo "WARNING: No conda environment is active. Activate the project environment first."
fi

# --- Python finds the extension module in bin

export PYTHONPATH="$BIN_DIR:$PYTHONPATH"
