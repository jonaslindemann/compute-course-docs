module particle_driver

    ! Interface wrapped by f2py. f2py can not handle derived types or
    ! kind parameters from other modules, so only plain real(8) and
    ! integer arguments are used here.
    !
    ! The particle system used by Python is the module variable psys
    ! in the particle_state module.

    use mf_datatypes
    use particle_state

    implicit none

contains

subroutine init_system(n, r_min, r_max, v_min, v_max)

    integer, intent(in) :: n
    real(8), intent(in) :: r_min, r_max
    real(8), intent(in) :: v_min, v_max

    ! TODO: Initialise psys

end subroutine init_system

subroutine get_positions(coords)

    real(8), intent(inout) :: coords(:,:)

    ! TODO: Copy the particle positions to coords
    !
    ! Python uses (n_particles, 3) arrays, but positions are stored as
    ! (3, n_particles) in the particle system.

end subroutine get_positions

subroutine get_sizes(sizes)

    real(8), intent(inout) :: sizes(:)

    ! TODO: Copy the particle radii to sizes

end subroutine get_sizes

subroutine write_sizes()

    ! TODO: Write the particle sizes to the state file

end subroutine write_sizes

subroutine write_steps(n)

    integer, intent(in) :: n

    ! TODO: Write the number of steps to the state file

end subroutine write_steps

subroutine collision_check()

    ! TODO: Check for particle collisions

end subroutine collision_check

subroutine boundary_check()

    ! TODO: Check for collisions with the walls

end subroutine boundary_check

subroutine update()

    ! TODO: Move the particles one time step

end subroutine update

subroutine write_positions()

    ! TODO: Write the particle positions to the state file

end subroutine write_positions

subroutine deallocate_system()

    ! TODO: Release the particle system

end subroutine deallocate_system

end module particle_driver
