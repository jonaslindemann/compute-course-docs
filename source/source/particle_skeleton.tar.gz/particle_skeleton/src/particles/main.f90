program particles

    use mf_datatypes
    use particle_data

    implicit none

    integer(ik), parameter :: n_particles = 500
    integer(ik), parameter :: n_steps = 1000

    ! Variables declared in the main program are never finalized, but
    ! variables local to a block are. psys is finalized at end block,
    ! which deallocates the arrays and closes the state file.

    block

        type(particle_system) :: psys

        ! TODO: Initialise the particle system with psys%init(). Use
        ! radius 0.005 - 0.015 and speed 0.001 - 0.009.

        ! TODO: Write the particle sizes and the number of steps to the
        ! state file (write_sizes and write_n_iterations).

        ! TODO: Run the simulation for n_steps steps. In each step:
        ! check collisions, check boundaries, update the positions and
        ! write the positions to the state file.

        ! TODO: Print a summary of the particle system with print_info.

    end block

end program particles
