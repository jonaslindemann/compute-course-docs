module particle_data

    use mf_datatypes

    implicit none

    private
    public :: particle_system

    character(len=*), parameter :: particle_state_file = 'particle.state'

    ! Particle system in a box. Positions and velocities are stored
    ! as (3, n_particles) so that the coordinates of a particle are
    ! contiguous in memory (Fortran is column-major).

    type :: particle_system
        integer(ik) :: n_particles = 0
        real(dp) :: box_min(3) = -1.0_dp
        real(dp) :: box_max(3) = 1.0_dp
        real(dp) :: r_min = 0.0_dp
        real(dp) :: r_max = 0.0_dp
        real(dp) :: v_max = 0.0_dp
        real(dp) :: dt = 0.0_dp
        real(dp), allocatable :: pos(:,:)
        real(dp), allocatable :: vel(:,:)
        real(dp), allocatable :: r(:)
        integer :: state_unit = -1
    contains
        procedure :: init
        procedure :: destroy
        procedure :: print_info
        procedure :: write_sizes
        procedure :: write_positions
        procedure :: write_n_iterations
        procedure :: update
        procedure :: check_boundary
        procedure :: check_collision
        final :: finalize
    end type particle_system

    ! Simulation procedures, implemented in the particle_sim submodule

    interface

        module subroutine update(this, dt)
            class(particle_system), intent(inout) :: this
            real(dp), intent(in), optional :: dt
        end subroutine update

        module subroutine check_boundary(this)
            class(particle_system), intent(inout) :: this
        end subroutine check_boundary

        module subroutine check_collision(this)
            class(particle_system), intent(inout) :: this
        end subroutine check_collision

    end interface

contains

subroutine init(this, n, r_min, r_max, v_min, v_max)

    class(particle_system), intent(inout) :: this
    integer(ik), intent(in) :: n
    real(dp), intent(in) :: r_min, r_max
    real(dp), intent(in) :: v_min, v_max

    ! TODO: Initialise the particle system
    !
    ! 1. Call destroy() first, so that init can be called more than once.
    !
    ! 2. Store n, r_min, r_max and v_max in the type.
    !
    ! 3. Compute the time step dt = r_min/(3*v_max). A particle must not
    !    move more than a third of the smallest radius in one step,
    !    otherwise collisions can be missed.
    !
    ! 4. Allocate pos(3,n), vel(3,n) and r(n).
    !
    ! 5. Initialise the random number generator with random_init().
    !
    ! 6. Give each particle a random radius in [r_min, r_max].
    !
    ! 7. Give each particle a random velocity. Draw a speed v in
    !    [v_min, v_max] and a direction given by the angles phi in
    !    [0, 2*pi] and theta in [-pi/2, pi/2]:
    !
    !        vx = v*cos(phi)*cos(theta)
    !        vy = v*sin(phi)*cos(theta)
    !        vz = v*sin(theta)
    !
    ! 8. Give each particle a random position inside the box
    !    [box_min, box_max], at least one diameter (2*r) from the walls.
    !
    ! Use whole array operations instead of loops where possible.

end subroutine init

subroutine destroy(this)

    class(particle_system), intent(inout) :: this

    if (allocated(this%pos)) deallocate(this%pos)
    if (allocated(this%vel)) deallocate(this%vel)
    if (allocated(this%r)) deallocate(this%r)

    if (this%state_unit /= -1) then
        close(this%state_unit)
        this%state_unit = -1
    end if

    this%n_particles = 0

end subroutine destroy

! Called automatically when a particle_system goes out of scope.
! Note that variables in the main program and in modules are never
! finalized, for those destroy() must be called explicitly.

subroutine finalize(this)

    type(particle_system), intent(inout) :: this

    call this%destroy()

end subroutine finalize

subroutine print_info(this)

    class(particle_system), intent(in) :: this

    character(len=*), parameter :: fmt = '(A,T22,3G16.6)'

    print '(A)', '----- Particle system ------------------------------------------'
    print '(A,T22,I0)', 'Number of particles', this%n_particles
    print fmt, 'Min position', minval(this%pos, dim=2)
    print fmt, 'Max position', maxval(this%pos, dim=2)
    print fmt, 'Min velocity', minval(this%vel, dim=2)
    print fmt, 'Max velocity', maxval(this%vel, dim=2)
    print fmt, 'Min/max radius', minval(this%r), maxval(this%r)
    print fmt, 'Time step', this%dt
    print '(A)', '----------------------------------------------------------------'

end subroutine print_info

! State file output. The file is created (replacing any old file)
! by the first write and closed by destroy().

subroutine open_state_file(this)

    class(particle_system), intent(inout) :: this

    if (this%state_unit == -1) then
        open(newunit=this%state_unit, file=particle_state_file, status='replace', action='write')
    end if

end subroutine open_state_file

subroutine write_sizes(this)

    class(particle_system), intent(inout) :: this

    call open_state_file(this)

    write(this%state_unit, '(I10)') this%n_particles
    write(this%state_unit, '(F12.5)') this%r

end subroutine write_sizes

subroutine write_positions(this)

    class(particle_system), intent(inout) :: this

    call open_state_file(this)

    ! The format is reused for each column of pos, one particle per line

    write(this%state_unit, '(I10)') this%n_particles
    write(this%state_unit, '(3F12.5)') this%pos

end subroutine write_positions

subroutine write_n_iterations(this, n)

    class(particle_system), intent(inout) :: this
    integer(ik), intent(in) :: n

    call open_state_file(this)

    write(this%state_unit, '(I10)') n

end subroutine write_n_iterations

end module particle_data
