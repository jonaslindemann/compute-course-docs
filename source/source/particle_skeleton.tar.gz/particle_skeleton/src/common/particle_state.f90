module particle_state

    use particle_data

    implicit none

    ! Particle system shared with the Python extension module

    type(particle_system) :: psys

end module particle_state
