submodule (particle_data) particle_sim

    ! Implementation of the simulation procedures declared in the
    ! interface block of the particle_data module.

    implicit none

contains

module subroutine update(this, dt)

    class(particle_system), intent(inout) :: this
    real(dp), intent(in), optional :: dt

    ! TODO: Move all particles one time step
    !
    !     pos = pos + vel*dt
    !
    ! Use the dt argument if it is present, otherwise the time step
    ! stored in the particle system (this%dt).

end subroutine update

module subroutine check_boundary(this)

    class(particle_system), intent(inout) :: this

    ! TODO: Bounce particles off the walls of the box
    !
    ! A particle hits a wall when its distance to the wall is less than
    ! its radius. The velocity component perpendicular to the wall must
    ! then point back into the box.
    !
    ! Hint: Setting the direction with abs() is more robust than just
    ! changing the sign of the velocity component. A particle that is
    ! already outside the box would otherwise change direction every
    ! step and get stuck in the wall.

end subroutine check_boundary

module subroutine check_collision(this)

    class(particle_system), intent(inout) :: this

    !       | -------------|
    !               d
    ! | --- o --- |   | -- o -- |
    !          r1       r2
    !
    ! TODO: Handle collisions between particles
    !
    ! For each pair of particles i < j:
    !
    ! 1. Compute n = pos(:,j) - pos(:,i). The particles overlap if the
    !    distance |n| is less than r(i) + r(j). Compare squared values
    !    to avoid computing a square root.
    !
    ! 2. If they overlap and are moving towards each other, that is
    !    dot_product(n, vel(:,j) - vel(:,i)) < 0, update the velocities
    !    for an elastic collision between particles of equal mass:
    !
    !        q = dot_product(n, vel(:,j) - vel(:,i)) / dot_product(n, n)
    !        vel(:,i) = vel(:,i) + q*n
    !        vel(:,j) = vel(:,j) - q*n
    !
    ! Collisions between more than two particles at the same time can
    ! be ignored.

end subroutine check_collision

end submodule particle_sim
