#!/bin/bash

source "$(dirname "$0")/config_env.sh"

# --- Run the Fortran program, writes particle.state

"$BIN_DIR/particles"
